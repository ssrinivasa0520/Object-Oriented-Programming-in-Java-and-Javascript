package Lab09;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

public class BookStoreTest {

	private BookStore store;
	private List<Book> localBookList;
	private Book b1 = new Book(1, "Harper Lee", "To Kill a Mockingbird");
	private Book b2 = new Book(2, "Harper Lee", "To Kill a Mockingbird");
	private Book b3 = new Book(3, "Frances Hodgson", "The Secret Garden");
	private Book b4 = new Book(5, "J.K. Rowling", "Harry Potter and the Sorcerer's Stone");
	private Book b5 = new Book(4, "Douglas Adams", "The Hitchhiker's Guide to the Galaxy");

	public List<Book> getBooks() {
		return localBookList;
	}
	
	public List<Book> getBooksSortedByTitle() {
		List<Book> temp = new ArrayList<Book>(getBooks());
		Collections.sort(temp, new Comparator<Book>() {
			public int compare(Book b1, Book b2) {
				return b1.getTitle().compareTo(b2.getTitle());
			}
		});
		return temp;
	}
	
	public List<Book> getBooksSortedByAuthor() {
		List<Book> temp = new ArrayList<Book>(getBooks());
		Collections.sort(temp, new Comparator<Book>() {
			public int compare(Book b1, Book b2) {
				return b1.getAuthorName().compareTo(b2.getAuthorName());
			}
		});
		return temp;
	}
	
	public int countBookWithTitle(String title) {
		int count = 0;
		for (Book book : getBooks()) {
			if (book.getTitle() == title) {
				count++;
			}
		}
		return count;
	}

	/**
	 * setup the store
	 * 
	 */
	@Before
	public void setUpBookStore() {
		store = new BookStore();
		store.addBook(b1);
		store.addBook(b2);
		store.addBook(b3);
		store.addBook(b4);
		localBookList = new ArrayList<Book>();
		localBookList.add(b1);
		localBookList.add(b2);
		localBookList.add(b3);
		localBookList.add(b4);

	}
	
	@Test
	public void testGetBooks() {
		assertEquals(getBooks(), store.getBooks());
	}

	/**
	 * tests the addition of book
	 * 
	 */

	@Test
	public void testAddBook() {
		store.addBook(b5);
		assertTrue(store.getBooks().contains(b5));

	}

	/**
	 * tests the deletion of book
	 * 
	 */

	@Test
	public void testDeleteBook() {
		store.addBook(b5);
		store.deleteBook(b5);
		assertFalse(store.getBooks().contains(b5));
	}

	/**
	 * tests sorting of books by author name
	 * 
	 */

	@Test
	public void testGetBooksSortedByAuthor() {
		assertEquals(getBooksSortedByAuthor(), store.getBooksSortedByAuthor());
	}

	/**
	 * tests sorting of books by title
	 * 
	 */

	@Test
	public void testGetBooksSortedByTitle() {
		assertEquals(getBooksSortedByTitle(), store.getBooksSortedByTitle());
	}

	/**
	 * tests the number of copies of book in store
	 * 
	 */

	@Test
	public void testCountBookWithTitle() {
		assertEquals(countBookWithTitle(b1.getTitle()), store.countBookWithTitle(b1.getTitle()));
	}

}
