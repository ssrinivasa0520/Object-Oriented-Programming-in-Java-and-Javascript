public class Generics {

	public static void main(String[] args) {
		
		Integer arr1[] = { -999994, 2, 3, 4, 5, 6, 7, 8, 9999999, 10 };
		
		Pair<Integer, Integer> minMaxPair = minMax(arr1);

		System.out.format("Minimum Element := %s\nMaximum Element := %s", minMaxPair.getValue1(),
				minMaxPair.getValue2());
		
		Integer arr2[] = { -99999, 2, 3, 4, 5, 6, 7, 8, 9999999 };

		Pair<Double, Double> avgSumPair = avgSum(arr2);

		System.out.format("\nAverage := %,f\nSum := %,f", avgSumPair.getValue1(),
				avgSumPair.getValue2());

	}

	public static <T extends Comparable<T>> Pair<T, T> minMax(T[] arr) {
		T min, max;
		if (arr.length > 0) {
			min = arr[0];
			max = arr[0];
			for (T e : arr) {
				if (e.compareTo(min) < 0) {
					min = e;
				}
				if (e.compareTo(max) > 0) {
					max = e;
				}
			}
			return new Pair<T, T>(min, max);
		} else {
			return new Pair<T, T>(null, null);
		}
	}

	public static <T extends Number> Pair<Double, Double> avgSum(T[] arr) {
		Double average = 0.0;
		Double sum = 0.0;

		for (T e : arr) {
			sum += e.doubleValue();
		}

		average = sum / arr.length;

		return new Pair<Double, Double>(average, sum);
	}

}
