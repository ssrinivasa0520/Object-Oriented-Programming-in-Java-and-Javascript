NAME: SHREYAS SRINIVASA
BLAZER ID: SSRINIVA

OUTPUT SCREENSHOTS ARE IN THE HOSPITAL SYSTEM.zip FILE AND IN THE PROJECT REPORT TOO.

- The role was not necessary for deletion operation because the Blazer IDs were assumed to be unique and all of the different types of employees are stored in a single data structure.
