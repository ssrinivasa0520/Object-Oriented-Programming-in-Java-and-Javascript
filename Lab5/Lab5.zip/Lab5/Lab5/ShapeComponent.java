import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.geom.Arc2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;

import javax.swing.JComponent;

public class ShapeComponent extends JComponent {

	private final int FRAME_WIDTH = 1000;
	private final int FRAME_HEIGHT = 600;

	private final int SKY_X = 0;
	private final int SKY_Y = 0;
	private final int SKY_WIDTH = FRAME_WIDTH;
	private final int SKY_HEIGHT = (int)(FRAME_HEIGHT * 0.6);
	
	private final int GRASS_X = 0;
	private final int GRASS_Y = SKY_Y + SKY_HEIGHT;
	private final int GRASS_WIDTH = FRAME_WIDTH;
	private final int GRASS_HEIGHT = FRAME_HEIGHT - SKY_HEIGHT;
	
	private final int TREE_X = 800;
	private final int TREE_Y = 300;
	private final int TREE_WIDTH = 40;
	private final int TREE_HEIGHT = 200;
	
	private final int HOUSE_WIDTH = 400;
	private final int HOUSE_HEIGHT = 150;
	private final int HOUSE_X = 120;
	private final int HOUSE_Y = 250;
	private final int ROOF_TOP = HOUSE_Y -100;
	private final int WINDOW_WIDTH = 50;
	private final int WINDOW_HEIGHT = 40;
	private final int DOOR_WIDTH = 40;
	private final int DOOR_HEIGHT = 70;
	private final int DOOR_Y = HOUSE_Y + 70;
	private final int DOOR_X = (((HOUSE_WIDTH / 2) + HOUSE_X) - (DOOR_WIDTH / 2));
	private final int LEFT_WINDOW_X = ((HOUSE_WIDTH / 4) + HOUSE_X) - (WINDOW_WIDTH / 2);
	private final int LEFT_WINDOW_Y = HOUSE_Y + 50;
	private final int RIGHT_WINDOW_X = (((HOUSE_WIDTH / 4) * 3) + HOUSE_X) - (WINDOW_WIDTH / 2);
	private final int RIGHT_WINDOW_Y = LEFT_WINDOW_Y;
	private final int KNOB_WIDTH = 10;
	private final int KNOB_HEIGHT = KNOB_WIDTH;

	public void paintComponent(Graphics g) {
		drawEnv(g);
		drawHouse(g);
		
		drawWindow(g, LEFT_WINDOW_X, LEFT_WINDOW_Y);
		drawWindow(g, RIGHT_WINDOW_X, RIGHT_WINDOW_Y);

		drawDoor(g, DOOR_X, DOOR_Y);
		
		drawTree(g, TREE_X, TREE_Y);
		
		drawName(g, FRAME_WIDTH - 200, FRAME_HEIGHT - 50);

	}
	
	private void drawEnv(Graphics g) {
		Graphics2D g2 = (Graphics2D)g;
		Color lightblue = new Color(200, 253, 255);
		
		Rectangle2D.Double sky = new Rectangle2D.Double(SKY_X, SKY_Y, SKY_WIDTH, SKY_HEIGHT);
		Rectangle2D.Double grass = new Rectangle2D.Double(GRASS_X, GRASS_Y, GRASS_WIDTH, GRASS_HEIGHT);
		
		g2.setColor(lightblue);
		g2.fill(sky);
		g2.setColor(Color.green);
		g2.fill(grass);
		
		Arc2D.Double sun = new Arc2D.Double(SKY_X + 30, SKY_Y + 30, 100, 100, 0, 360, Arc2D.PIE);
		g2.setColor(Color.yellow);
		g2.fill(sun);
	}

	private void drawHouse(Graphics g) {
		
		Graphics2D g2 = (Graphics2D)g;
		g2.setStroke(new BasicStroke(7));
		Color lightbrown = new Color(220, 118, 51);

		Rectangle2D.Double wall = new Rectangle2D.Double(HOUSE_X, HOUSE_Y, HOUSE_WIDTH, HOUSE_HEIGHT);
		g2.setColor(Color.black);
		g2.draw(wall);
		g2.setColor(lightbrown);
		g2.fill(wall);
		
		
		int[] xPoints = { HOUSE_X, (HOUSE_X - 10), ((HOUSE_WIDTH / 2) + HOUSE_X),  (HOUSE_X + HOUSE_WIDTH + 10), (HOUSE_X + HOUSE_WIDTH - 10)};
		int[] yPoints = { HOUSE_Y, HOUSE_Y, ROOF_TOP, HOUSE_Y, HOUSE_Y};
		
		Polygon roof = new Polygon(xPoints, yPoints, 5);
		g2.setColor(Color.black);
		g2.draw(roof);
		g2.setColor(Color.red);
		g2.fill(roof);
		
		Rectangle2D.Double chimney = new Rectangle2D.Double(((HOUSE_WIDTH * 0.75) + HOUSE_X), ROOF_TOP * 1.2, 20, 50);
		g2.setColor(Color.black);
		g2.draw(chimney);
		g2.setColor(Color.magenta);
		g2.fill(chimney);
	}

	private void drawWindow(Graphics g, int x, int y) {
		Graphics2D g2 = (Graphics2D)g;
		g2.setStroke(new BasicStroke(3));

		Rectangle2D.Double window = new Rectangle2D.Double(x, y, WINDOW_WIDTH, WINDOW_HEIGHT);
		g2.setColor(Color.blue);
		g2.draw(window);
		g2.setColor(Color.white);
		g2.fill(window);
		
		g2.setColor(Color.blue);
		// draw horizontal line
		g2.drawLine(x, (y + (WINDOW_HEIGHT / 2)), (x + WINDOW_WIDTH), (y + (WINDOW_HEIGHT / 2)));
		// draw vertical line
		g2.drawLine((x + (WINDOW_WIDTH / 2)), (y + WINDOW_HEIGHT), (x + (WINDOW_WIDTH / 2)), y);
	}

	private void drawDoor(Graphics g, int x, int y) {
		g.setColor(Color.black);
		g.fillRect(x, y, DOOR_WIDTH, DOOR_HEIGHT);
		
		Graphics2D g2 = (Graphics2D)g;
		g2.setStroke(new BasicStroke(3));

		Rectangle2D.Double door = new Rectangle2D.Double(x, y, DOOR_WIDTH, DOOR_HEIGHT);
		g2.setColor(Color.blue);
		g2.draw(door);
		g2.setColor(Color.green);
		g2.fill(door);
		
		g2.setColor(Color.blue);
		g2.fillOval(((x + DOOR_WIDTH) - KNOB_WIDTH), (y + (DOOR_HEIGHT / 2)), KNOB_WIDTH, KNOB_HEIGHT);
	}

	private void drawTree(Graphics g, int x, int y) {
		
		Graphics2D g2 = (Graphics2D)g;
		final int CROWN_SIZE = 180;
		Color darkgreen = new Color(30, 132, 73);

		Rectangle2D.Double trunk = new Rectangle2D.Double(x, y, TREE_WIDTH, TREE_HEIGHT);
		Color brown = new Color(160, 64, 0);
		g2.setColor(brown);
		g2.fill(trunk);
		
		Arc2D.Double crown = new Arc2D.Double(x + TREE_WIDTH / 2 - CROWN_SIZE / 2, y - CROWN_SIZE + 30, CROWN_SIZE, CROWN_SIZE, 0, 360, Arc2D.PIE);
		g2.setColor(darkgreen);
		g2.fill(crown);
	}
	
	private void drawName(Graphics g, int x, int y) {
		Graphics2D g2 = (Graphics2D)g;
		g2.setColor(Color.black);
		g2.drawString("SHREYAS SRINIVAS : SSRINIVA", x, y);
	}
	
	private static final long serialVersionUID = 1L;

}
