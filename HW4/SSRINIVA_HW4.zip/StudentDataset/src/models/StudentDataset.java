package models;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class StudentDataset {
	
	private final List<StudentRecord> studentDataset;
	private final String datasetFilePath;
	private static String datasetHeadings;
	public static final String datasetHeadingsFormatString = "%-15s %-15s %-20s %-15s %-15s %-15s %-5s %-15s";
	

	public StudentDataset(List<StudentRecord> studentDataset) {
		super();
		this.studentDataset = studentDataset;
		datasetFilePath = "";
	}

	public StudentDataset(String filePath) {
		super();
		datasetFilePath = filePath; 
		studentDataset = new ArrayList<StudentRecord>();
		readStudentsFromFile();
	}
	
	public List<StudentRecord> getStudentDataset() {
		return studentDataset;
	}

	public void readStudentsFromFile() {

		Path file = Paths.get(datasetFilePath);
		Charset charset = Charset.forName("UTF-8");

		try (BufferedReader reader = Files.newBufferedReader(file, charset)) {
			String line = null;
			String dataH[] = reader.readLine().split(",");
			//System.out.println(Arrays.toString(dataH));
			
			datasetHeadings = String.format(datasetHeadingsFormatString, dataH[0].substring(2), dataH[1], dataH[2], dataH[3], dataH[4], dataH[5], dataH[6], dataH[7]);
			//System.out.println(datasetHeadings);
			while ((line = reader.readLine()) != null) {
				String data[] = line.split(",");
				studentDataset.add(new StudentRecord(
						data[0], 
						data[1], 
						data[2], 
						data[3], 
						Float.valueOf(data[4]), 
						Float.valueOf(data[5]), 
						data[6].equals("Yes") ? true : false,
						data[7]
				));
			}
		} catch (IOException x) {
			System.err.format("IOException: %s%n", x);
		}
	}

	public void add(StudentRecord student) {
		studentDataset.add(student);
	}
	
	public void display() {
		System.out.println(datasetHeadings);
		for(StudentRecord student: studentDataset) {
			System.out.println(student);
		}
	}
	
}
