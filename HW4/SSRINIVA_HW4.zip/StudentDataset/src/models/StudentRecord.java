package models;

public class StudentRecord {
	
	private String firstName;
	private String lastName;
	private String major;
	private String degree;
	private float GPA;
	private float creditHours;
	private boolean isTA;
	private String advisor;
	
	public static final String recordDisplayFormatString = "%-15s %-15s %-20s %-15s %-15.2f %-15.2f %-5s %-15s";
	
	
	public StudentRecord(String firstName, String lastName, String major, String degree, float gPA, float creditHours,
			boolean isTA, String advisor) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.major = major;
		this.degree = degree;
		GPA = gPA;
		this.creditHours = creditHours;
		this.isTA = isTA;
		this.advisor = advisor;
	}
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getMajor() {
		return major;
	}
	public void setMajor(String major) {
		this.major = major;
	}
	public String getDegree() {
		return degree;
	}
	public void setDegree(String degree) {
		this.degree = degree;
	}
	public float getGPA() {
		return GPA;
	}
	public void setGPA(float gPA) {
		GPA = gPA;
	}
	public float getCreditHours() {
		return creditHours;
	}
	public void setCreditHours(float creditHours) {
		this.creditHours = creditHours;
	}
	public boolean isTA() {
		return isTA;
	}
	public void setTA(boolean isTA) {
		this.isTA = isTA;
	}
	public String getAdvisor() {
		return advisor;
	}
	public void setAdvisor(String advisor) {
		this.advisor = advisor;
	}

//	@Override
//	public String toString() {
//		return "StudentRecord [firstName=" + firstName + ", lastName=" + lastName + ", major=" + major + ", degree="
//				+ degree + ", GPA=" + GPA + ", creditHours=" + creditHours + ", isTA=" + (isTA ? "Yes" : "No") + ", advisor=" + advisor
//				+ "]";
//	}
	
	@Override
	public String toString() {
		return String.format(recordDisplayFormatString,  firstName, lastName, major, degree, GPA, creditHours, (isTA ? "Yes" : "No"), advisor);
	}
}
