package main;

import models.StudentDataset;

public class Driver {

	public static void main(String[] args) {
		
		final String csvFilePath = "./students_dataset.csv";
		
		StatisticsCalculator calc = new StatisticsCalculator(new StudentDataset(csvFilePath));
		
		calc.displayAdvisors();
		calc.displayStudentsWithGPALessThan(2.75f);
		calc.displayAvgCreditHours();
		calc.displayAvgGPAofCSDept();
		calc.displayDeptsWithTotalAdvisors();

	}

}
