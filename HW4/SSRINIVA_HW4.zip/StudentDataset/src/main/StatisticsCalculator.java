package main;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import models.StudentDataset;
import models.StudentRecord;

public class StatisticsCalculator {

	StudentDataset studentDataset;

	public StatisticsCalculator(StudentDataset studentDataset) {
		super();
		this.studentDataset = studentDataset;
	}

	public void displayAdvisors() {

		Set<String> advisors = new HashSet<String>();

		for (StudentRecord student : studentDataset.getStudentDataset()) {
			advisors.add(student.getAdvisor());
		}

		System.out.println("We have " + advisors.size() + " advisors. Their names are:\n");

		for (String advisor : advisors) {
			System.out.println(advisor);
		}
	}

	public void displayStudentsWithGPALessThan(float GPA) {

		List<StudentRecord> students = new ArrayList<StudentRecord>();

		for (StudentRecord student : studentDataset.getStudentDataset()) {
			if (student.getGPA() < GPA) {
				students.add(student);
			}
		}

		System.out.println("\nWe have " + students.size() + " students with GPA less than (" + GPA + "). They are:\n");

		StudentDataset studentsD = new StudentDataset(students);

		studentsD.display();

	}

	public void displayAvgCreditHours() {
		float avgCH = 0f;
		List<StudentRecord> students = studentDataset.getStudentDataset();

		for (StudentRecord student : students) {
			avgCH += student.getCreditHours();
		}

		avgCH /= students.size();

		System.out.println(String.format("\nThe average credit hours: (%.4f)", avgCH));
	}

	public void displayAvgGPAofCSDept() {
		float avgGPACS = 0f;
		int countCS = 0;

		List<StudentRecord> students = studentDataset.getStudentDataset();

		for (StudentRecord student : students) {
			if (student.getMajor().equals("Computer Science")) {
				avgGPACS += student.getGPA();
				countCS++;
			}
		}

		avgGPACS /= countCS;

		System.out.println(String.format("\nThe average GPA of the Computer Science department: (%.4f)", avgGPACS));
	}

	public void displayDeptsWithTotalAdvisors() {

		Map<String, HashSet<String>> deptAdvisors = new HashMap<String, HashSet<String>>();

		List<StudentRecord> students = studentDataset.getStudentDataset();

		for (StudentRecord student : students) {
			String major = student.getMajor();
			deptAdvisors.putIfAbsent(major, new HashSet<String>());
			deptAdvisors.get(major).add(student.getAdvisor());
		}

		System.out.println("\nThe list of departments with the total number of advisors:\n");
		System.out.println(String.format("%-20s %-30s", "Department", "Total No. of Advisors"));
		for (Map.Entry<String, HashSet<String>> entry : deptAdvisors.entrySet()) {
			System.out.println(String.format("%-20s %-30d", entry.getKey(), entry.getValue().size()));
		}
	}

}
