import java.io.PrintWriter;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Scanner;

public class FileIO {

	public static void main(String[] args) {
		
		String numbers[];
		ArrayList<Integer> sumOfLines = new ArrayList<Integer>();
		
		try (Scanner fileScanner = new Scanner(Paths.get("tester.txt"))) {
			while(fileScanner.hasNextLine()) {
				String line = fileScanner.nextLine();
				numbers = line.split(",");
				sumOfLines.add(calcArraySum(numbers));
			}
			fileScanner.close();
		} catch (Exception e) {
			System.out.println("Error: " + e.toString());
		}
		
		try (PrintWriter output = new PrintWriter("output.txt")) {
			for(int sum: sumOfLines) {
				output.println(sum);
			}
			output.close();
		} catch (Exception e) {
			System.out.println("Error: " + e.toString());
		}

	}
	
	public static int calcArraySum(String numbers[]) {
		int sum = 0;
		for(String i: numbers) {
			sum += Integer.valueOf(i);
		}
		return sum;
	}

}
