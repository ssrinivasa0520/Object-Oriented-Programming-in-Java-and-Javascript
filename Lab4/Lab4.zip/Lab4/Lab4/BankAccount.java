public class BankAccount {

	private String firstName, lastName;

	private int accountNumber;
	private double balance = 0;
	private double loan = 0;
	private double interest = 0.05;

	public BankAccount(double initialBalance) {
		this.balance = initialBalance;
	}

	/**
	 * This function sets the first and last name of this object based on the given
	 * values for first and last
	 * 
	 * @param first
	 * @param last
	 */
	public void setName(String first, String last) {
		this.firstName = first;
		this.lastName = last;
	}

	/**
	 * This function sets the account number based on the given value for accNo
	 * 
	 * @param accNo
	 */
	public void setAccountNumber(int accNo) {
		this.accountNumber = accNo;
	}

	/**
	 * This function returns the first and last name of the owner of this account
	 * 
	 * @return first and last name of the account holder combined with a space in between
	 */
	public String getName() {
		return this.firstName + " " + this.lastName;
	}

	/**
	 * This function returns the accNo for this object
	 * 
	 * @return account number of the bank account
	 */
	public int getAccountNumber() {
		return this.accountNumber;
	}

	/**
	 * This function returns the balance for this account
	 * 
	 * @return account balance of the bank account
	 */
	public double getBalance() {
		return this.balance;
	}

	/**
	 * This function performs a deposit into the account by adding the value of
	 * amount to the balance
	 * 
	 * @param amount
	 */
	public void deposit(double amount) {
		this.balance += amount;
	}

	/**
	 * This function performs a withdrawal from the account and returns the amount
	 * withdrawn
	 * If there is insufficient balance it returns 0
	 * 
	 * @param amount
	 * @return amount withdrawn if withdraw successful, else 0
	 */
	public double withdraw(double amount) {
		if (amount <= this.balance) {
			this.balance -= amount;
			return amount;
		} else {
			return 0;
		}
	}

	/**
	 * This function provides assigns a requested amount as loan to the account with
	 * the required interest rate
	 * 
	 * @param principal
	 * @param interest
	 */
	public void setLoan(double principal, double interest) {
		this.loan = principal;
		this.interest = interest;
		this.balance += principal;
	}

	/**
	 * This function returns the interest amount owed on the loan availed 
	 * by the account based on the tenure in years.
	 * 
	 * @param time
	 * @return the calculated interest based on loan amount and tenure
	 */
	public double getInterest(double time) {
		return (this.loan * this.interest * time);
	}
	/**
	 * This function checks whether the account number belonging to the 
	 * account is an Armstrong number.
	 * 
	 * @return true if bank account number is armstrong else false
	 */
	public boolean isAccountNumberArmstrong() {
		int sodc = 0;
		int accNo = this.accountNumber;
		int nod = String.valueOf(accNo).length();
		while(accNo > 0) {
			sodc += Math.pow(accNo % 10, nod);
			accNo /= 10;
		}
		if(sodc == this.accountNumber) return true;
		return false;
	}

}
