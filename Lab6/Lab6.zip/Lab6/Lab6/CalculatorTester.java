import java.util.Scanner;

public class CalculatorTester {

	public static void main(String[] args) {
		
		int num1, num2;
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter two integers");
		System.out.print("Enter num1: ");
		num1 = sc.nextInt();
		System.out.print("Enter num2: ");
		num2 = sc.nextInt();
		
		ScientificCalculator calc = new ScientificCalculator(num1, num2);
		
		System.out.println("Addition of " + num1 + " and " + num2 + " is: " + calc.add());
		System.out.println("Subtraction of " + num1 + " and " + num2 + " is: " + calc.subtract());
		System.out.println("Multiplication of " + num1 + " and " + num2 + " is: " + calc.multiply());
		System.out.println("Division of " + num1 + " and " + num2 + " is: " + calc.divide());
		
		System.out.println("Square root of " + num1 + " is: " + calc.squareRoot(1));
		System.out.println("Square root of " + num2 + " is: " + calc.squareRoot(2));
		
		System.out.println("Exponent of " + num1 + " to the power of " + num2 + " is: " + calc.exponent(1, num2));
		System.out.println("Exponent of " + num2 + " to the power of " + num1 + " is: " + calc.exponent(2, num1));

	}

}
