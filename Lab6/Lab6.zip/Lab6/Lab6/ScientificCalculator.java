
public class ScientificCalculator extends Calculator{

	ScientificCalculator(int num1, int num2) {
		super(num1, num2);
	}
	
	public double squareRoot(int n) {
		if(n == 1) return Math.sqrt(this.getNum1());
		else if(n == 2) return Math.sqrt(this.getNum2());
		return 0;
	}
	
	public double exponent(int n, double exp) {
		if(n == 1) return Math.pow(this.getNum1(), exp);
		else if(n == 2) return Math.pow(this.getNum2(), exp);
		return 0;
	}
	
}
