
public class UABPerson {
	private String name;
	private String gender;
	private int age;
	private String blazerID;
	
	public UABPerson(String name, String gender, int age, String blazerID) {
		this.name = name;
		this.gender = gender;
		this.age = age;
		this.blazerID = blazerID;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getBlazerID() {
		return blazerID;
	}
	public void setBlazerID(String blazerID) {
		this.blazerID = blazerID;
	}
	
	public boolean checkPalindrome() {
		String name = this.getName().toLowerCase();
		int length = name.length();
		for(int i = 0;i < length / 2;i++) {
			if(name.charAt(i) != name.charAt(length - i - 1)) {
				return false;
			}
		}
		return true;
	}
	
	public int yearsUntilRetirement() {
		return (65 - this.getAge());
	}
	
	public String toString() {
		return String.format("%s is %d years old", this.getName(), this.getAge());
	}
	
}
