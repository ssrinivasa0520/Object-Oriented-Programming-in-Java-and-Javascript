
public class UABPersonTester {
	public static void main(String args[]) {
		UABPerson person1 = new UABPerson("Morton", "Male", 20, "ID1");
		UABPerson person2 = new UABPerson("Hannah", "Female", 23, "ID2");
		
		System.out.println(person1.toString());
		System.out.println("Name is palindrome: " + person1.checkPalindrome());
		System.out.println("Years until retirement: " + person1.yearsUntilRetirement());
		
		
		System.out.println(person2.toString());
		System.out.println("Name is palindrome: " + person2.checkPalindrome());
		System.out.println("Years until retirement: " + person2.yearsUntilRetirement());
	}
}
