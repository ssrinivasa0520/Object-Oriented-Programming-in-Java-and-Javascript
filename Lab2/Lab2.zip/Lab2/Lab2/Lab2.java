import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class HW2 {
	public static void main(String args[]) {
		fileAnalyze();
		sec2days(750000);
		sec2days(1234);
		sec2days(200000);
		consonantCount("abra cadabra");
		consonantCount("how many consonants?");
		consonantCount("This is Lab2, folks");
	}
	
	public static void fileAnalyze() {
		String line;
		int e, count = 0, max = Integer.MIN_VALUE, min = Integer.MAX_VALUE, sum = 0;
		int average;
		try {
			BufferedReader in  = new BufferedReader(
					new FileReader(new File("inputFile.txt")));
			BufferedWriter out  = new BufferedWriter(
					new FileWriter(new File("outputFile.txt")));
			while((line=in.readLine())!=null) {
				e = Integer.valueOf(line);
				count++;
				sum += e;
				if(e < min) min = e;
				if(e > max) max = e;
				out.write(line + "\n");
			}
			average = sum / count;
			out.write("**********\n");
			out.write("There are " + count + " numbers in this file\n");
			out.write("The minimum number is " + min + "\n");
			out.write("The maximum number is " + max + "\n");
			out.write("The average is " + average + "\n");
			
			in.close();
			out.close();
		}
		catch (IOException error) {
			System.out.println(error.getMessage());
		}
	}

	public static String sec2days(int n) {
		int days = n / (3600 * 24);
		n %= (3600 * 24);
		int hours = n / (3600);
		n %= 3600;
		int minutes = n / 60;
		n %= 60;
		int seconds = n;
		String result = String.format("%d:%02d:%02d:%02d", days, hours, minutes, seconds);
		System.out.println(result);
		return result;
	}
	
	public static int consonantCount(String s) {
		s = s.toLowerCase();
		List<Character> vowels = new ArrayList<>();
		vowels.add('a');
		vowels.add('e');
		vowels.add('i');
		vowels.add('o');
		vowels.add('u');
		vowels.add('y');
		
		
		int consonantCount = 0;
		for(int i = 0; i < s.length(); i++) {
			if(!vowels.contains(s.charAt(i)) && s.charAt(i) >= 'a' && s.charAt(i) <= 'z') {
				consonantCount++;
			}
		}
		System.out.println(consonantCount);
		return consonantCount;
	}
}
