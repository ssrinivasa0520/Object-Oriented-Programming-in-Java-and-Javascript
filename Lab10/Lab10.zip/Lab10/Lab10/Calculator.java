import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

public class Calculator extends JFrame {
	private static final long serialVersionUID = 1L;

	JButton btnAdd, btnSubtract, btnDivide, btnMultiply, btnSqrt, btnClear, btnDelete, btnEquals, btnDot;
	JButton numBtn[];
	JTextField output;
	NumberBtnHandler numBtnHandler;
	OtherBtnHandler otherBtnHandler;
	OperatorBtnHandler opBtnHandler;
	JPanel mainPanel, row1, row2, row3, row4, row5, grid;
	String previous = "", current = "", operator;

	public Calculator() {
		super("CS203 Lab 10 - SSRINIVA");

		this.initPanels();
		this.initActionListeners();
		this.initButtons();
		this.initOutputField();

		this.setupRowPanels();
		this.setupMainPanel();

		this.add(mainPanel);
		this.pack();
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);
		this.setSize(500, 600);
		//this.setResizable(false);
	}

	void initPanels() {
		mainPanel = new JPanel();
		row1 = new JPanel();
		row2 = new JPanel();
		row3 = new JPanel();
		row4 = new JPanel();
		row5 = new JPanel();
	}

	void initButtons() {

		final int BUTTON_FONT_SIZE = 40;
		final int BUTTON_WIDTH = 120;
		final int BUTTON_HEIGHT = 90;

		btnSubtract = new JButton("-");
		btnAdd = new JButton("+");
		btnDivide = new JButton("÷");
		btnMultiply = new JButton("*");
		btnSqrt = new JButton("√");
		btnDot = new JButton(".");
		btnEquals = new JButton("=");
		btnClear = new JButton("C");
		btnDelete = new JButton("D");

		numBtn = new JButton[11];
		numBtn[10] = btnDot;
		for (int count = 0; count < numBtn.length - 1; count++) {
			numBtn[count] = new JButton(String.valueOf(count));
			numBtn[count].setFont(new Font("Monospaced", Font.BOLD, BUTTON_FONT_SIZE));
			numBtn[count].setMaximumSize(new Dimension(BUTTON_WIDTH, BUTTON_HEIGHT));
			numBtn[count].addActionListener(numBtnHandler);
		}

		btnDot.setFont(new Font("Monospaced", Font.BOLD, BUTTON_FONT_SIZE));
		btnDot.setMaximumSize(new Dimension(BUTTON_WIDTH, BUTTON_HEIGHT));

		btnEquals.setFont(new Font("Monospaced", Font.BOLD, BUTTON_FONT_SIZE));
		btnEquals.setMaximumSize(new Dimension(BUTTON_WIDTH, BUTTON_HEIGHT));

		btnAdd.setFont(new Font("Monospaced", Font.BOLD, BUTTON_FONT_SIZE));
		btnAdd.setMaximumSize(new Dimension(BUTTON_WIDTH, BUTTON_HEIGHT));

		btnSubtract.setFont(new Font("Monospaced", Font.BOLD, BUTTON_FONT_SIZE));
		btnSubtract.setMaximumSize(new Dimension(BUTTON_WIDTH, BUTTON_HEIGHT));

		btnDivide.setFont(new Font("Monospaced", Font.BOLD, BUTTON_FONT_SIZE));
		btnDivide.setMaximumSize(new Dimension(BUTTON_WIDTH, BUTTON_HEIGHT));

		btnMultiply.setFont(new Font("Monospaced", Font.BOLD, BUTTON_FONT_SIZE));
		btnMultiply.setMaximumSize(new Dimension(BUTTON_WIDTH, BUTTON_HEIGHT));
		
		btnSqrt.setFont(new Font("Monospaced", Font.BOLD, BUTTON_FONT_SIZE));
		btnSqrt.setMaximumSize(new Dimension(BUTTON_WIDTH, BUTTON_HEIGHT));

		btnClear.setFont(new Font("Monospaced", Font.BOLD, BUTTON_FONT_SIZE));
		btnClear.setMaximumSize(new Dimension(BUTTON_WIDTH, BUTTON_HEIGHT));

		btnDelete.setFont(new Font("Monospaced", Font.BOLD, BUTTON_FONT_SIZE));
		btnDelete.setMaximumSize(new Dimension(BUTTON_WIDTH, BUTTON_HEIGHT));

		btnDot.addActionListener(numBtnHandler);
		btnDelete.addActionListener(otherBtnHandler);
		btnClear.addActionListener(otherBtnHandler);
		btnEquals.addActionListener(otherBtnHandler);

		btnMultiply.addActionListener(opBtnHandler);
		btnAdd.addActionListener(opBtnHandler);
		btnSubtract.addActionListener(opBtnHandler);
		btnDivide.addActionListener(opBtnHandler);
		btnSqrt.addActionListener(numBtnHandler);

	}

	void initOutputField() {

		final int OUTPUT_FONT_SIZE = 50;
		final int OUTPUT_WIDTH = 485;
		final int OUTPUT_HEIGHT = 80;

		output = new JTextField(10);

		output.setMaximumSize(new Dimension(OUTPUT_WIDTH, OUTPUT_HEIGHT));
		output.setFont(new Font("Monospaced", Font.BOLD, OUTPUT_FONT_SIZE));
		output.setDisabledTextColor(new Color(0, 0, 0));
		output.setMargin(new Insets(0, 5, 0, 0));
		output.setEditable(false);
		output.setText("");
	}

	void initActionListeners() {
		numBtnHandler = new NumberBtnHandler();
		otherBtnHandler = new OtherBtnHandler();
		opBtnHandler = new OperatorBtnHandler();
	}

	void setupRowPanels() {
		row1.setLayout(new BoxLayout(row1, BoxLayout.LINE_AXIS));
		row2.setLayout(new BoxLayout(row2, BoxLayout.LINE_AXIS));
		row3.setLayout(new BoxLayout(row3, BoxLayout.LINE_AXIS));
		row4.setLayout(new BoxLayout(row4, BoxLayout.LINE_AXIS));
		row5.setLayout(new BoxLayout(row5, BoxLayout.LINE_AXIS));

		//row1.add(Box.createHorizontalGlue());
		//row1.setAlignmentX(Component.RIGHT_ALIGNMENT);
		row1.add(Box.createRigidArea(new Dimension(120, 90)));
		row1.add(btnClear);
		row1.add(btnDelete);
		row1.add(btnSqrt);
		row2.add(numBtn[7]);
		row2.add(numBtn[8]);
		row2.add(numBtn[9]);
		row2.add(btnMultiply);
		row3.add(numBtn[4]);
		row3.add(numBtn[5]);
		row3.add(numBtn[6]);
		row3.add(btnAdd);
		row4.add(numBtn[1]);
		row4.add(numBtn[2]);
		row4.add(numBtn[3]);
		row4.add(btnSubtract);
		row5.add(btnDot);
		row5.add(numBtn[0]);
		row5.add(btnEquals);
		row5.add(btnDivide);
	}

	void setupMainPanel() {
		mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.PAGE_AXIS));
		mainPanel.add(Box.createRigidArea(new Dimension(0, 5)));
		mainPanel.add(output);
		mainPanel.add(Box.createRigidArea(new Dimension(0, 15)));
		mainPanel.add(row1);
		mainPanel.add(row2);
		mainPanel.add(row3);
		mainPanel.add(row4);
		mainPanel.add(row5);
	}

	private class NumberBtnHandler implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			JButton selectedBtn = (JButton) e.getSource();
			String num = selectedBtn.getText();
			enterNumber(num);
		}
	}

	private class OperatorBtnHandler implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			JButton selectedBtn = (JButton) e.getSource();
			selectOperator(selectedBtn.getText());
		}
	}

	private class OtherBtnHandler implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			JButton selectedBtn = (JButton) e.getSource();
			if (selectedBtn == btnDelete) {
				delete();
			} else if (selectedBtn == btnClear) {
				clear();
			} else if (selectedBtn == btnEquals) {
				calculate();
			}
		}
	}

	public void delete() {
		if (current.length() > 0) {
			current = current.substring(0, current.length() - 1);
			setOutput(getOutput().substring(0, getOutput().length() - 1));
		}
	}

	public void clear() {
		current = "";
		previous = "";
		operator = null;
		setOutput("");
	}

	public String getOutput() {
		return output.getText();
	}

	public void updateOutput(String value) {
		output.setText(output.getText() + value);
	}

	public void setOutput(String value) {
		output.setText(value);
	}

	public void enterNumber(String num) {
		if (num.equals(".") && current.contains(".")) {
			return;
		}
		if (num.equals("√") && (current.contains("√") || !current.isEmpty())) {
			return;
		}
		current += num;
		updateOutput(num);
	}

	public void selectOperator(String newOperator) {
		if(current.equals("√")) {
			return;
		}
		
		if(current.isEmpty()) {
			if (newOperator.equals("-")) {
				current += newOperator;
				updateOutput(newOperator);
				return;
			}
			return;
		}

		if (!previous.isEmpty()) {
			calculate();
		}
		
		operator = newOperator;
		previous = current;
		current = "";
		updateOutput(operator);
	}

	public void processOutputNumber() {
		if (current.length() > 0) {
			String integerPart = current.split("\\.")[0];
			String decimalPart = current.split("\\.")[1];
			if (decimalPart.equals("0")) {
				current = integerPart;
			}
		}
	}

	public void calculate() {
		if ((previous.length() < 1 && current.length() < 1) || current.equals("√")) {
			return;
		}
		double result = 0.0;
		double num1 = 0;
		double num2 = 0; 
		
		if(!previous.isEmpty()) {
			if(previous.startsWith("√")) {
				num1 = Math.sqrt(Double.parseDouble(previous.substring(1)));
			} else {
				num1 = Double.parseDouble(previous);
			}
		}
		if(current.startsWith("√")) {
			num2 = Math.sqrt(Double.parseDouble(current.substring(1)));
		} else {
			num2 = Double.parseDouble(current);
		}
		
		result = num2;
		
		if(operator != null) {
			switch (operator) {
			case "*":
				result = num1 * num2;
				break;
			case "+":
				result = num1 + num2;
				break;
			case "-":
				result = num1 - num2;
				break;
			case "÷":
				result = num1 / num2;
				break;
			default:
				result = num2;
			}
		}
		result = Math.round(result * 10000000) / 10000000.0;
		current = String.valueOf(result);
		operator = null;
		previous = "";
		processOutputNumber();
		setOutput(current);
	}
}
