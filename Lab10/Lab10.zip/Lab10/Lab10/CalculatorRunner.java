public class CalculatorRunner {
	public static void main(String[] args) {
		new Calculator();
	}
}
