import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;

public class StudentTester {

	private static final String filePath = "studentList.txt";
	private static final String outputFilePath = "studentGrades.txt";

	public static void main(String[] args) {
		ArrayList<Student> students = readStudentsFromFile();
		for(Student s: students) {
			System.out.println(s);
		}
		writeStudentsToFile(students);

	}

	public static ArrayList<Student> readStudentsFromFile() {

		ArrayList<Student> students = new ArrayList<Student>();

		Path file = Paths.get(filePath);
		Charset charset = Charset.forName("US-ASCII");

		try (BufferedReader reader = Files.newBufferedReader(file, charset)) {
			String line = null;
			while ((line = reader.readLine()) != null) {
				String data[] = line.split(",");
				students.add(new Student(data[0], data[1], data[2], data[3]));
			}
		} catch (IOException x) {
			System.err.format("IOException: %s%n", x);
		}

		return students;
	}

	public static ArrayList<Student> writeStudentsToFile(ArrayList<Student> students) {

		Path file = Paths.get(outputFilePath);
		Charset charset = Charset.forName("US-ASCII");

		try (BufferedWriter writer = Files.newBufferedWriter(file, charset)) {
			for(Student s: students) {
				String fileRecord = s.toString() + "\n";
				writer.write(fileRecord, 0, fileRecord.length());
			}
		} catch (IOException x) {
			System.err.format("IOException: %s%n", x);
		}

		return students;
	}

}
