public class Student {
	
	private String name;
	private double examGrades[] = new double[3];
	private double finalGrade;
	private char letterGrade;
	
	public Student(String name, String exam1, String exam2, String finalExam) {
		this.name = name;
		this.examGrades[0] = Double.valueOf(exam1);
		this.examGrades[1] = Double.valueOf(exam2);
		this.examGrades[2] = Double.valueOf(finalExam);
		this.setFinalGrade();
		this.setLetterGrade();
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double[] getExamGrades() {
		return examGrades;
	}

	public void setExamGrades(double[] examGrades) {
		this.examGrades = examGrades;
	}

	public double getFinalGrade() {
		return finalGrade;
	}

	public void setFinalGrade(double finalGrade) {
		this.finalGrade = finalGrade;
	}
	
	public void setFinalGrade() {
		finalGrade = (0.25 * examGrades[0]) + (0.25 * examGrades[1]) + (0.5 * examGrades[2]);
	}

	public char getLetterGrade() {
		return letterGrade;
	}

	public void setLetterGrade(char letterGrade) {
		this.letterGrade = letterGrade;
	}
	
	public void setLetterGrade() {
		if(finalGrade >= 90) {
			letterGrade = 'A';
		} else if (finalGrade >= 80) {
			letterGrade = 'B';
		} else if (finalGrade >= 70) {
			letterGrade = 'C';
		} else {
			letterGrade = 'F';
		}
	}
	
	public String toString() {
		return name + " received a grade of " + finalGrade + ": " + letterGrade;
	}

}
