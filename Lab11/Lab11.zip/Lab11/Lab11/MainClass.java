public class MainClass {

	public static void main(String[] args) {
		ConcreteClass1 cc1 = new ConcreteClass1();
		ConcreteClass2 cc2 = new ConcreteClass2();
		ConcreteClass3 cc3 = new ConcreteClass3();
		
		cc1.concrete_method();
		cc1.abstract_method();
		cc1.instance_method();
		
		cc2.instance_method1();
		cc2.instance_method2();
		cc2.interface_method();
		
		cc3.instance_method1();
		cc3.instance_method2();

	}

}
