abstract class AbstractClass {
	public void concrete_method() {
		System.out.println("AbstractClass Concrete Method");
	}
	abstract void abstract_method();
}
