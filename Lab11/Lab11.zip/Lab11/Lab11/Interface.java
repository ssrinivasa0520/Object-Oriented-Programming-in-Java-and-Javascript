public interface Interface {
	public void interface_method();
}
