public class ConcreteClass3 extends ConcreteClass2 {

	public ConcreteClass3() {
		super();
	}
	
	@Override
	public void instance_method1() {
		System.out.println("ConcreteClass3 Instance Method 1");
		super.instance_method1();
	}
	
	public void instance_method2() {
		System.out.println("ConcreteClass3 Instance Method 2");
	}

}
