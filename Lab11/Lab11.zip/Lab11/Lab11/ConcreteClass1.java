public class ConcreteClass1 extends AbstractClass{
	
	

	public ConcreteClass1() {
		super();
	}

	@Override
	void abstract_method() {
		System.out.println("Implementation of abstract method of abstract superclass - Abstract in concrete subclass - ConcreteClass1");
		
	}
	
	public void instance_method() {
		System.out.println("ConcreteClass1 Instance Method");
	}
	
}
