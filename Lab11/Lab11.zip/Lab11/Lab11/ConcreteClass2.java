public class ConcreteClass2 implements Interface{

	public ConcreteClass2() {
		super();
	}
	
	public void instance_method1() {
		System.out.println("ConcreteClass2 Instance Method 1");
	}
	
	public void instance_method2() {
		System.out.println("ConcreteClass2 Instance Method 2");
	}

	@Override
	public void interface_method() {
		System.out.println("Implementation of abstract method of superinterface - Interface in concrete subclass - ConcreteClass2");
		
	}
	
}
